﻿#include <iostream>
#include "consoleApp.h"
#include "storage.h"
#include "crow_all.h"

// додати видалення користувача та його історії
int main() {
    const int MAX = 100;

    CoffeeStorage coffeeStorage(MAX);
    TestStorage testStorage(MAX);
    CoffeeCategoryStorage categoryStorage(MAX);
    CoffeeSelectorStorage selectorStorage(MAX);
    ResultStorage resultStorage(MAX);
    UserStorage userStorage(MAX);

    coffeeStorage.loadFromAnyFile("coffee.dat", "coffee_backup.dat");
    testStorage.loadFromAnyFile("myTest.dat", "myTest_backup.dat");
    categoryStorage.loadFromAnyFile("coffeeCategory.dat", "coffeeCategory_backup.dat");
    selectorStorage.loadFromAnyFile("coffeeSelector.dat", "coffeeSelector_backup.dat");
    resultStorage.loadFromAnyFile("resultTest.dat", "resultTest_backup.dat");
    userStorage.loadFromAnyFile("user.dat", "user_backup.dat");

    categoryStorage.loadDefaultsIfEmpty();
    coffeeStorage.loadDefaultsIfEmpty();

    crow::SimpleApp server;

    CROW_ROUTE(server, "/")([]() {
        return "Crow REST API server is running!";
        });

    CROW_ROUTE(server, "/api/test")([]() {
        crow::json::wvalue response;
        response["message"] = "Hello from Crow REST API";
        response["status"] = "ok";
        return response;
        });

    CROW_ROUTE(server, "/meals")([]() {
        crow::response response;

        std::ifstream file("meals.html");
        if (!file.is_open()) {
            response.code = 404;
            response.write("meals.html not found");
            return response;
        }

        std::string html(
            (std::istreambuf_iterator<char>(file)),
            std::istreambuf_iterator<char>()
        );

        response.code = 200;
        response.set_header("Content-Type", "text/html; charset=utf-8");
        response.write(html);
        return response;
        });

    std::cout << "Server started!\n";
    std::cout << "Open: http://localhost:18080/\n";
    std::cout << "Test API: http://localhost:18080/api/test\n";
    std::cout << "Meals page: http://localhost:18080/meals\n";

    server.port(18080).multithreaded().run();

    coffeeStorage.saveToTwoFiles("coffee.dat", "coffee_backup.dat");
    testStorage.saveToTwoFiles("myTest.dat", "