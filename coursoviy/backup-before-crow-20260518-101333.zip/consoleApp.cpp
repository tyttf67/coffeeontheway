﻿#include "consoleApp.h"
#include "coffeeSelector.h"
#include "coffeeCatalog.h"

#include <iostream>
#include <limits>
#include <cctype>

ConsoleApp::ConsoleApp(
    CoffeeStorage& coffeeStorage,
    TestStorage& testStorage,
    CoffeeCategoryStorage& categoryStorage,
    CoffeeSelectorStorage& selectorStorage,
    ResultStorage& resultStorage,
    UserStorage& userStorage
) : coffeeStorage(coffeeStorage),
    testStorage(testStorage),
    categoryStorage(categoryStorage),
    selectorStorage(selectorStorage),
    resultStorage(resultStorage),
    userStorage(userStorage),
    currentUser(),
    isLoggedIn(false) {
}
void ConsoleApp::runAndSaveTestForCurrentUser() {
    const int userId = currentUser.getId();

    const int newAttemptId = resultStorage.getNextAttemptIdForUser(userId);

    int testCount = 0;
    const Test* tests = getDefaultTests(testCount);

    std::cout << "\n=== Test (Attempt #" << newAttemptId << ") ===\n";
    for (int i = 0; i < testCount; ++i) {
        tests[i].show();

        char answer = 0;
        while (true) {
            std::cout << "Your answer (A/B/C): ";
            if (!(std::cin >> answer)) {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }
            answer = static_cast<char>(std::toupper(static_cast<unsigned char>(answer)));
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            if (tests[i].getCoffeeIndexForChoice(answer) != -1) {
                break;
            }
            std::cout << "Please enter only A, B, or C.\n";
            
        }
        

        if (!resultStorage.addAnswerForUserAttempt(userId, newAttemptId, tests[i].getId(), answer)) {
            std::cout << "Cannot save result (result storage is full).\n";
            return;
        }


       
        std::cout << "-------------------------\n";
        
    }
   
   
    std::cout << "Test completed and saved to history.\n";
    
}

void ConsoleApp::printCurrentUserHistory() const {
    const Result* results = resultStorage.data();
    const int resultCount = resultStorage.getCount();

    int testCount = 0;
    const Test* tests = getDefaultTests(testCount);

    int coffeeCount = 0;
    const Coffee* coffees = getDefaultCoffees(coffeeCount);

    bool found = false;
    int currentAttempt = -1;

    for (int i = 0; i < resultCount; ++i) {
        if (results[i].getUserId() != currentUser.getId()) {
            continue;
        }

        if (!found) {
            std::cout << "\n=== Test history ===\n";
        }

        if (results[i].getAttemptId() != currentAttempt) {
            currentAttempt = results[i].getAttemptId();
            std::cout << "\nAttempt #" << currentAttempt << '\n';
        }

        const Test* test = nullptr;
        for (int j = 0; j < testCount; ++j) {
            if (tests[j].getId() == results[i].getQuestionId()) {
                test = &tests[j];
                break;
            }
        }

        std::cout << "Question " << results[i].getQuestionId() << ": ";
        if (test) {
            std::cout << test->getQuestionText() << '\n';
            std::cout << "Answer: " << results[i].getChoice()
                << ") " << test->getAnswerTextForChoice(results[i].getChoice()) << '\n';

            const int coffeeIndex = test->getCoffeeIndexForChoice(results[i].getChoice());
            if (coffeeIndex >= 0 && coffeeIndex < coffeeCount) {
                std::cout << "Matched coffee: " << coffees[coffeeIndex].getName()
                    << " | Group: " << categoryStorage.getNameById(coffees[coffeeIndex].getCategoryId()) << '\n';
            }
        } else {
            std::cout << "Unknown question\n";
            std::cout << "Answer: " << results[i].getChoice() << '\n';
        }

        std::cout << "-------------------------\n";
        found = true;
    }

    if (!found) {
        std::cout << "No test history for current user yet.\n";
    }
}
void ConsoleApp::addCoffeeToFavourites() {
    if (!isLoggedIn) {
        std::cout << "Login first.\n";
        return;
    }

    char query[128];
    std::cout << "Enter coffee name: ";
    std::cin.getline(query, sizeof(query));

    int matches[20];
    const int matchCount = coffeeStorage.findByNameContains(query, matches, 20);
    if (matchCount == 0) {
        std::cout << "No coffee found.\n";
        return;
    }

    int selectedIndex = matches[0];
    if (matchCount > 1) {
        std::cout << "\nFound coffees:\n";
        for (int i = 0; i < matchCount; ++i) {
            const Coffee* coffee = coffeeStorage.getByIndex(matches[i]);
            if (coffee) {
                std::cout << i + 1 << ". " << coffee->getName()
                    << " | Group: " << categoryStorage.getNameById(coffee->getCategoryId()) << '\n';
            }
        }

        int choice = 0;
        while (true) {
            std::cout << "Choose number: ";
            if (!(std::cin >> choice)) {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            if (choice >= 1 && choice <= matchCount) {
                selectedIndex = matches[choice - 1];
                break;
            }

            std::cout << "Choose a number from the list.\n";
        }
    }

    const Coffee* selectedCoffee = coffeeStorage.getByIndex(selectedIndex);
    if (!selectedCoffee) {
        std::cout << "Cannot add coffee to favourites.\n";
        return;
    }

    if (!userStorage.addFavouriteDrinkForUser(currentUser.getId(), selectedCoffee->getName(), currentUser)) {
        std::cout << "Cannot add favourite drink. Favourite list may be full.\n";
        return;
    }

    std::cout << selectedCoffee->getName() << " added to favourites.\n";
}

void ConsoleApp::deleteCurrentAccount() {
    if (!isLoggedIn) {
        std::cout << "Login first.\n";
        return;
    }

    char answer = 0;
    std::cout << "Delete your account and test history? (Y/N): ";
    std::cin >> answer;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    answer = static_cast<char>(std::toupper(static_cast<unsigned char>(answer)));

    if (answer != 'Y') {
        std::cout << "Account deletion cancelled.\n";
        return;
    }

    const int userId = currentUser.getId();
    const int removedResults = resultStorage.removeByUserId(userId);

    if (!userStorage.removeById(userId)) {
        std::cout << "Cannot delete account.\n";
        return;
    }

    currentUser = User();
    isLoggedIn = false;

    std::cout << "Account deleted. Removed history records: " << removedResults << '\n';
}

void ConsoleApp::run() {
    while (true) {
        std::cout << "\n=== MENU ===\n";
        std::cout << "1. List coffee cards\n";
        std::cout << "2. Search coffee card\n";
        std::cout << "3. Register user\n";
        std::cout << "4. Login\n";
        std::cout << "5. Start test\n";
        std::cout << "6. Show user\n";
        std::cout << "7. Add coffee to favourites\n";
        std::cout << "8. Delete account\n";
        std::cout << "0. Exit\n";
        std::cout << "Choice: ";

        int choice = -1;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (choice == 0) {
            break;
        } else if (choice == 1) {
            selector.printCoffeeCards(categoryStorage);
        } else if (choice == 2) {

            char query[128];
            std::cout << "Enter search text: ";
            std::cin.getline(query, sizeof(query));

            if (!coffeeStorage.searchAndPrintByName(query, categoryStorage)) {
                std::cout << "No cards found.\n";
            }

        } else if (choice == 3) {

            char name[100];
            char gmail[100];
            char login[64];
            char password[64];
            char favouriteDrinks[100];

            std::cout << "Name: ";
            std::cin.getline(name, sizeof(name));
            std::cout << "Gmail: ";
            std::cin.getline(gmail, sizeof(gmail));
            std::cout << "Login: ";
            std::cin.getline(login, sizeof(login));
            std::cout << "Password: ";
            std::cin.getline(password, sizeof(password));
            std::cout << "Favourite drinks (comma-separated): ";
            std::cin.getline(favouriteDrinks, sizeof(favouriteDrinks));

            const int newUserId = userStorage.getCount() + 1;
            User newUser(newUserId, name, login, gmail, password, favouriteDrinks);

            if (userStorage.registerUser(newUser)) {
                std::cout << "User registered and saved in storage.\n";
            }
            else {
                std::cout << "Registration failed (login may already exist or storage is full).\n";
            }



            
        } else if (choice == 4) {


            char inLogin[64];
            char inPass[64];
            std::cout << "Login: ";
            std::cin.getline(inLogin, sizeof(inLogin));
            std::cout << "Password: ";
            std::cin.getline(inPass, sizeof(inPass));

            User foundUser;
            if (userStorage.loginUser(inLogin, inPass, foundUser)) {
                currentUser = foundUser;
                isLoggedIn = true;
                std::cout << "Logged in successfully.\n";
            }
            else {
                isLoggedIn = false;
                std::cout << "Wrong login/password.\n";
            }

        }
    
     else if (choice == 5) {
     if (!isLoggedIn) {
         std::cout << "Login first.\n";
         continue;
     }
   
     runAndSaveTestForCurrentUser();

     int coffeeCount = 0;
     const Coffee* coffees = getDefaultCoffees(coffeeCount);
     int testCount = 0;
     const Test* tests = getDefaultTests(testCount);

     int scores[20] = { 0 };
     const Result* allResults = resultStorage.data();
     int totalRes = resultStorage.getCount();
     int lastAttempt = resultStorage.getNextAttemptIdForUser(currentUser.getId()) - 1;

    
     for (int i = 0; i < totalRes; ++i) {
         if (allResults[i].getUserId() == currentUser.getId() && allResults[i].getAttemptId() == lastAttempt) {
             for (int j = 0; j < testCount; ++j) {
                 if (tests[j].getId() == allResults[i].getQuestionId()) {
                     int idx = tests[j].getCoffeeIndexForChoice(allResults[i].getChoice());
                     if (idx >= 0 && idx < 20) scores[idx]++;
                 }
             }
         }
     }

  
     int bestIdx = 0;
     for (int i = 1; i < coffeeCount; ++i) {
         if (scores[i] > scores[bestIdx]) bestIdx = i;
     }

     std::cout << "\n=== Based on your latest test ===\n";
     coffees[bestIdx].show();
     std::cout << "Category: " << categoryStorage.getNameById(coffees[bestIdx].getCategoryId()) << "\n";
     }
                
          else if (choice == 6) {
            
            if (!isLoggedIn) {
                std::cout << "No active user session. Login first.\n";
                continue;
            }
            currentUser.show();
            printCurrentUserHistory();            
        } else if (choice == 7) {

            addCoffeeToFavourites();
        } else if (choice == 8) {

            deleteCurrentAccount();
        } else {
            std::cout << "Unknown menu item.\n";
        }
    }
}

